import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState } from "react";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">Mindful Space</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-8">
        <div className="max-w-4xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const posts = useQuery(api.posts.listPosts);
  const [newPost, setNewPost] = useState("");

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold accent-text mb-4">Mindful Space</h1>
        <Authenticated>
          <p className="text-xl text-slate-600">
            Welcome, {loggedInUser?.email ?? "friend"}! Share with mindfulness.
          </p>
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600">Join our mindful community</p>
          <SignInForm />
        </Unauthenticated>
      </div>

      <Authenticated>
        <div className="bg-white rounded-lg shadow p-6 space-y-4">
          <h2 className="text-2xl font-semibold">Our Commitment</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h3 className="text-xl font-medium">Mental & Physical Health</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Screen time tracking and gentle reminders</li>
                <li>Content filtered for positivity and respect</li>
                <li>Mindfulness prompts and meditation breaks</li>
                <li>No infinite scrolling or addictive features</li>
                <li>Wellness score for all content</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-medium">UAE Values & Traditions</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>Cultural context awareness</li>
                <li>Respect for local customs and values</li>
                <li>Multi-language support with cultural nuance</li>
                <li>Content moderation aligned with UAE guidelines</li>
                <li>Focus on meaningful connections</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <textarea
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            className="w-full p-4 border rounded-lg"
            placeholder="Share your thoughts mindfully..."
            rows={3}
          />
          <div className="flex justify-between items-center mt-4">
            <div className="text-sm text-slate-500">
              Focus on positive, respectful communication
            </div>
            <button
              onClick={() => {
                // Handle post creation
                setNewPost("");
              }}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Share Mindfully
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {posts?.map((post) => (
            <div key={post._id} className="bg-white rounded-lg shadow p-6">
              <p className="text-lg">{post.content}</p>
              <div className="mt-2 text-sm text-slate-500">
                {new Date(post._creationTime).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      </Authenticated>
    </div>
  );
}
