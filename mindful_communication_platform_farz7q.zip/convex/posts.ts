import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createPost = mutation({
  args: {
    content: v.string(),
    category: v.string(),
    culturalContext: v.array(v.string()),
    language: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Basic content moderation
    const wellnessScore = calculateWellnessScore(args.content);
    const isModerated = wellnessScore < 0.7;

    return await ctx.db.insert("posts", {
      authorId: userId,
      content: args.content,
      category: args.category,
      culturalContext: args.culturalContext,
      wellnessScore,
      isModerated,
      language: args.language,
    });
  },
});

export const listPosts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    return await ctx.db
      .query("posts")
      .filter((q) => q.eq(q.field("isModerated"), false))
      .order("desc")
      .collect();
  },
});

function calculateWellnessScore(content: string): number {
  // Simple example - would use more sophisticated analysis in production
  const positiveWords = ["happy", "grateful", "respect", "kind"];
  const negativeWords = ["hate", "angry", "offensive"];
  
  let score = 0.8; // Base score
  const words = content.toLowerCase().split(" ");
  
  words.forEach(word => {
    if (positiveWords.includes(word)) score += 0.1;
    if (negativeWords.includes(word)) score -= 0.2;
  });
  
  return Math.max(0, Math.min(1, score));
}
