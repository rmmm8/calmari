import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  posts: defineTable({
    authorId: v.id("users"),
    content: v.string(),
    category: v.string(),
    culturalContext: v.array(v.string()),
    wellnessScore: v.number(),
    isModerated: v.boolean(),
    language: v.string(),
  }).index("by_author", ["authorId"]),
  
  wellnessMetrics: defineTable({
    userId: v.id("users"),
    screenTime: v.number(),
    positiveInteractions: v.number(),
    mindfulnessMinutes: v.number(),
    timestamp: v.number(),
  }).index("by_user", ["userId"]),

  culturalGuidelines: defineTable({
    category: v.string(),
    guidelines: v.array(v.string()),
    traditions: v.array(v.string()),
    sensitivePhrases: v.array(v.string()),
  }).index("by_category", ["category"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
